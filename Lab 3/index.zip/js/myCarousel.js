const myCarousel = new Carousel(document.querySelector(".carousel"), {
  // Options
});